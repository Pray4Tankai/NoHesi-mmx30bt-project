<?php
    function get_products(){

        $query = "SELECT * FROM `products`";
        $run_query = mysqli_query(dbConnect(),$query);

        return $run_query;
    }