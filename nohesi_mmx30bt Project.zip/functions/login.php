<?php

    if(isset($_POST)){
        if(isset($_POST['user_login'])){
            $username = $_POST['username'];
            $password = $_POST['password'];
            
            if(check_user($username))
            {
                $login = user_login($username,$password);
                if($login === false){
                    $errors[] = 'Username and password Combination is incorrect';
                }else{
                    $_SESSION['user_id'] = $login;
                    header("Location:../nohesi");
                    exit();
                }
            }else{
                $errors[] = 'Username does not exist in our database';
            }
        }
    }