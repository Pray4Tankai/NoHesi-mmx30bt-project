<?php
include_once '../core/init.php';
    if(isset($_POST)){
        if(isset($_POST['addCart'])){
            if(logged_in()){
                $product_id = $_POST['product_id'];
                $added = addToCart($product_id);
                if($added === true){
                    header("Location: ../shop.php");
                }
                else{
                    echo 'not added duh';
                }
            }else{
                header("Location: ../login.php");
            }
        }
        if(isset($_POST['removeItem'])){
            $productId = $_POST['product_id'];
            $user_id = $_SESSION['user_id'];
            $removed = removeCart($productId,$user_id);

            if($removed){
                header('Location:../cart.php');
            }
            else{
                echo 'eish';
            }
        }
    }