var userIcon = document.getElementById('userIcon');
var lockIcon = document.getElementById('lockIcon');

window.addEventListener('click', closeOpts);

function closeOpts(e){
    if(userIcon !==  null){
        if(e.target !== userIcon){
            $('.user-opt').removeClass('user-opt-open');
        }
    }
    if(lockIcon !==  null){
        if(e.target !== lockIcon){
            $('.lock-opt').removeClass('lock-opt-open');
        }
    }
}

$(function(){
    function header(){
        $('#cartIcon').click(function(){
            $('.section').addClass('shit-section');
            $('.aside').addClass('open-aside');
            $('#cartCont').addClass('open-cart');
        });
        $('.side-overlay').click(function(){
            removeMenu();
            console.log('click');
        });
        $('#lockIcon').click(function(){
            $('.lock-opt').toggleClass('lock-opt-open');
        });
        $('#userIcon').click(function(){
            $('.user-opt').toggleClass('user-opt-open');
        });
    }
    function removeOpt(){
        $('.lock-opt').removeClass('lock-opt-open');
        $('.user-opt').removeClass('user-opt-open');
    }
    function removeMenu(){
        $('.aside').removeClass('open-aside');
        $('#cartCont').addClass('open-cart');
        $('.section').removeClass('shit-section');
    }
    $(document).ready(function(){
        header();
    });
    $(window).on('resize',function(){
        // removeOpt();
        // removeMenu();
    });
})