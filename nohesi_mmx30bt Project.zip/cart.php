<?php
    include_once 'core/init.php';
    if(logged_in() === false){
        header("Location:login.php");
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        include_once 'includes/head.php';
    ?>
    <link rel="stylesheet" href="assets/css/cart.css">
    <title>No Hesi Apparel</title>
</head>
<body>
    <?php
        include_once 'includes/header.php';
    ?>
    <section>
        <div class="cart">
            <div>
                <div class="heading">
                    <h1>Your cart</h1>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th><i class="fa-trash"></i></th>
                            <th>Product Name</th>
                            <th>Unit Price</th>
                            <th>Product ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $cart = getCart();
                            $no = 1;
                            $subtotal = 0;
                            while($items = mysqli_fetch_assoc($cart)){
                                $product_name = $items['product_name'];
                                $product_price = $items['product_price'];
                                $product_id = $items['product_id'];

                                echo
                                    '
                                    <tr>
                                        <th>'.$no.'</th>
                                        <th>
                                            <form action="functions/cart.php" method="post">
                                                <input type="text" name="product_id" id="" value="'.$product_id.'" hidden>
                                                <button type="submit" class="fa-remove" name="removeItem"></button>
                                            </form>
                                        </th>
                                        <th>No Hesi '.$product_name.'</th>
                                        <th>$'.$product_price.'.00</th>
                                        <th>'.$product_id.'</th>
                                    </tr>';

                                $no = $no + 1;
                                $subtotal = $subtotal + $product_price;
                            }
                            echo '
                                    </tbody>
                                </table>
                                <div class="total">
                                    <div>
                                        <small>Total Price: </small>
                                        <span>$'.$subtotal.'.00</span>
                                    </div>
                                </div>';
                        ?>
            </div>
        </div>
    </section>
    <?php
        include_once 'includes/scripts.php';
    ?>
</body>
</html>